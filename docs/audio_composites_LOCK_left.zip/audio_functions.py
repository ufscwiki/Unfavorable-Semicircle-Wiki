import ffmpeg
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp

def extract_audio(input_file):
    try:
        audio, _ = (
            ffmpeg.input(input_file)
            .output('-', format='f32le', acodec='pcm_f32le')
            .run(capture_stdout=True, capture_stderr=True)
        )
        np_array = np.frombuffer(audio, dtype=np.float32)
        return np_array
    except ffmpeg.Error as e:
        print(f"Error extracting audio: {e.stderr}")
        return None
    
def save_audio_to_file(audio, output_file):
    try:
        with open(output_file, 'wb') as f:
            f.write(audio.tobytes())
        print(f"Audio saved to {output_file}")
    except IOError as e:
        print(f"Error saving audio: {e}")

def load_audio_from_file(input_file):
    try:
        with open(input_file, 'rb') as f:
            audio = np.frombuffer(f.read(), dtype=np.float32)
        return audio
    except IOError as e:
        print(f"Error loading audio: {e}")
        return None
    
def reshape_and_pad_array(input_array, x):
    # Reshape the array into a 2D array with x as the size of the first dimension
    reshaped_array = input_array[:x * (len(input_array) // x)].reshape(x, -1)
    
    # Determine the amount of padding needed
    padding = x - (len(input_array) % x)
    
    # Pad the second dimension with zeros
    padded_array = np.pad(reshaped_array, ((0, 0), (0, padding)), mode='constant')
    
    return padded_array    
    
def extract_peaks(signal, blocksize = 128, offset = 0):
    def split_with_offset_and_pad(arr, chunk_size, offset, pad_value=0):
        # Apply offset by slicing the array
        arr_sliced = arr[offset:]
        # Calculate the number of elements to pad
        pad_length = chunk_size - len(arr_sliced) % chunk_size
        # Pad the array
        arr_padded = np.pad(arr_sliced, (0, pad_length), constant_values=pad_value)
        # Split the padded array into chunks of specified size
        chunks = np.array_split(arr_padded, len(arr_padded) // chunk_size)
        return np.array(chunks)

    def calculate_baseline_mean(points, lower_percentage_begin = 0.05, lower_percentage_end = 0.3):
        # Sort the points
        sorted_points = np.sort(points)
        
        # Calculate the index up to which to consider lower values
        lower_index_begin = int(len(sorted_points) * lower_percentage_begin)
        lower_index_end = int(len(sorted_points) * lower_percentage_end)
        
        # Take the mean of the lower values
        baseline_mean = np.mean(sorted_points[lower_index_begin:lower_index_end])
        
        return baseline_mean
    signal_split = split_with_offset_and_pad(signal, blocksize, offset)
    baseline = np.zeros(signal_split.shape[0])
    peak = np.zeros(signal_split.shape[0])
    peak_pos = np.zeros(signal_split.shape[0])
    for i,arr in enumerate(signal_split):
        peak[i] = np.max(arr)
        peak_pos[i] = np.argmax(arr)+i*blocksize+offset
        baseline[i] = calculate_baseline_mean(arr)
    return peak_pos, peak, baseline
    
    
def reshape_and_pad(array, n):
    # Calculate the size of the original array
    m = array.shape[0]//n
    if m*n is not array.shape[0]:
        missing = n - array.shape[0]%n
        print(f"{m=}, {n=}, {missing=}")
        array = np.pad(array, (0, missing), mode='constant')
    
    return array.reshape((-1, n))

